package com.example;

import java.awt.Desktop;
import java.net.URI;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

@Environment(value=EnvType.CLIENT)
public class FrostClientsClient
implements ClientModInitializer {
    private int tickCounter = 0;
    private boolean waiting = false;

    public void onInitializeClient() {
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            if (client.method_1558() != null && client.method_1558().field_3761.toLowerCase().contains("donutsmp.net")) {
                this.waiting = true;
                this.tickCounter = 0;
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            this.waiting = false;
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!this.waiting) {
                return;
            }
            ++this.tickCounter;
            if (this.tickCounter >= 200) {
                this.waiting = false;
                FrostClientsClient.openBrowser("https://donutsmp.net");
            }
        });
    }

    private static void openBrowser(String url) {
        try {
            Desktop.getDesktop().browse(new URI(url));
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
